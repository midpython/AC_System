from os import system,remove
from shutil import copyfile

help_docs = """using     调用包
dir       查看安装的所有包
指定一个值可以查询是否安装成功
uninstall 卸载包
后部添加true后可删除该系统目录下所有非系统指定默认安装的包
默认只删除一个指定的包
install   安装包
ctm    再次打开一个本系统窗口
help      查看帮助文档
quit      退出系统
exit      退出系统"""
InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList = ["rfs.py","control.py","msg.py","blues.py","setup.py","dos.py","other.py","ty.py","commands.py"]
SystemDefaultBagsList = ["rfs.py","control.py","msg.py","blues.py","setup.py","dos.py","other.py","ty.py","commands.py"]

def using(BagName:str):
    BagName = str(BagName) + ".py"
    system(BagName)

def dir(Object:str=None,
        mobels:str="0"):
    # "0" is print all bagnames
    # "1" is print object bag
    if mobels == "0":
        for Ob in InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList:
            print(InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList[Ob])

    elif mobels == "1":
        if Object in InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList:
            print(InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList[InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList.index(Object)])
        else:
            print("Not Found")
def uninstall(BagName:str,all:str="false"):
    if all == "false":
        BagName = str(BagName) + ".py"
        remove(BagName)
    elif all == "true":
        for BagNames in InstallBagAndSystemDefaultInstallBagAndSystemDefaultBagList:
            if BagNames != SystemDefaultBagsList:
                BagNames = str(BagNames) + ".py"
                remove(BagName)
    else:
        print("Not Found")

def install(BagPath:str):
    copyfile(BagPath, "sys_main.py")

def ctm():
    system("sys_main.py")

def help_funtion():
    print(help_docs)
    
def main():
    while True:
        model = str(input("<Now:/>:"))
        modules = model.split()
        if modules[0] == "help":
            help_funtion()
        elif modules[0] == "using":
            using(modules[1])
        elif modules[0] == "dir":
            if modules[1] != None:
                dir(modules[1],"1")
            else:
                dir(None,"0")
        elif modules[0] == "uninstall":
            uninstall(modules[1])
        elif modules[0] == "install":
            install(modules[1])
        elif modules[0] == "ctm":
            ctm()
        elif modules[0] == "quit" or modules[0] == "exit":
            quit()
        else:
            print("没有此命令行")

if __name__ == "__main__":
    main()